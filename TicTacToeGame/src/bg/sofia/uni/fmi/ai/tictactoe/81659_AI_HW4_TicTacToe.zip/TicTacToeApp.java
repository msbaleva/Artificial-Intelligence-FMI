package bg.sofia.uni.fmi.ai.tictactoe;


public class TicTacToeApp {
	
	
	public static void main(String[] args) {
		
		
		Game.getInstance().play();
	}

}
